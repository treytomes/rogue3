function two(x)
   print(x)
end
function one(y)
   print(y)
   two('go')
   print('there')
end

one('dolly')


