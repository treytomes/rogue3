This is a base64 library for Lua 5.1. For information on base64 see
	http://en.wikipedia.org/wiki/Base64

To try the library, just edit Makefile to reflect your installation of Lua and
then run make. This will build the library and run a simple test. For detailed
installation instructions, see
	http://www.tecgraf.puc-rio.br/~lhf/ftp/lua/install.html

There is no manual but the library is simple and intuitive; see the summary
below. Read also test.lua, which shows the library in action.

This code is hereby placed in the public domain.
Please send comments, suggestions, and bug reports to lhf@tecgraf.puc-rio.br .

-------------------------------------------------------------------------------

base64 library:
 decode(s) 	 encode(s) 	 version 

-------------------------------------------------------------------------------
