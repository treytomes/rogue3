
World generator 0.1.0

Fast (< 1 sec for a 400×400 map)
Heightmap, precipitation map, latitude-dependant temperature map, biome map
Rain erosion
Rapidely Exploring Random Tree rivers

http://doryen.eptalys.net/demos/


